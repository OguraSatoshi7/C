#include <stdio.h>
#include "myFunctions.h"


typedef struct Node Nodeptr;

typedef struct Node
{
	int data;
	Nodeptr* next;
	Nodeptr* previous;
	
} Nodeptr;

extern Nodeptr * start; // We called exterm because it's being defined on a different file, in this case "myFunction.c"
extern Nodeptr * endNode;// We called exterm because it's being defined on a different file, in this case "myFunction.c"

int main()
{
	//it may give you some error or warnings for some compilers
	//no init
	int choice;
	start = NULL;
	endNode = NULL;

	do
	{
		printf("1 - add (left) | 2- add (right) |  5 - print | ");
		puts("99 - extend the menu | ");
		scanf("%d", &choice);

		switch (choice)
		{
		case 99:
			menu();
			break;
		case 1:			
			addToLeft();
			break;
		case 2:
			addToRight();
			break;
		case 5:
			printTheNodes();
			break;
		default:
			printf("please enter a valid number\n\n");
			break;
		}

	} while (choice != 0);
	   
	return 0;
}

