//
//  myFunctions.c
//  project1
//
//  Created by Saygin Guven on 2019-07-16.
//  Copyright � 2019 Saygin Guven. All rights reserved.
//

#include "myFunctions.h"

typedef struct Node Nodeptr;

typedef struct Node
{
	int data;
	Nodeptr* next;
	Nodeptr* previous;
} Nodeptr;

Nodeptr * start;
Nodeptr * endNode;

void printTheNodes() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
		puts("");
	}
	else if(start == endNode) {		
		printf("Linked List : {%d}\n",start->data);
	}
	else
	{
		Nodeptr* current;
		current = start;
		printf("Linked List : {");
		while (current != NULL)
		{
			printf("%d ", current->data);
			current = current->next;
		}
		printf("}");
		puts("");
	}
}

void printTheNodesBackwards() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
		puts("");
	}
	else if (start == endNode) {
		printf("Linked List : {%d}\n", start->data);
	}
	else
	{
		Nodeptr* current;
		current = endNode;
		printf("Linked List : {");
		while (current != NULL)
		{
			printf("%d ", current->data);
			current = current->previous;
		}
		printf("}");
		puts("");
	}
}

void addToLeft() {
	Nodeptr * currentTemp = (Nodeptr*)malloc(sizeof(Nodeptr));	
	if (start == NULL && endNode == NULL)
	{
		puts("Add the Data");
		scanf("%d", &currentTemp->data);
		
		start = currentTemp;
		endNode = currentTemp;
		start->next = NULL;
		start->previous = NULL;
	}
	else {
		puts("Add the Data");
		scanf("%d", &currentTemp->data);
		start->previous = currentTemp;
		currentTemp->next = start;
		currentTemp->previous = NULL;
		start = currentTemp;
	}
	printTheNodes();
}

void addToRight() {
	Nodeptr * currentTemp = (Nodeptr*)malloc(sizeof(Nodeptr));
	if (start == NULL && endNode == NULL)
	{
		puts("Add the Data");
		scanf("%d", &currentTemp->data);
		start = currentTemp;
		endNode = currentTemp;
		start->next = NULL;
		start->previous = NULL;
	}
	else {
		puts("Add the Data");
		scanf("%d", &currentTemp->data);
		endNode->next = currentTemp;
		currentTemp->previous = endNode;
		currentTemp->next = NULL;
		endNode = currentTemp;
	}
	printTheNodes();
}

void addMiddleAfter() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
	}

	int data;
	printf("After which Node?\n");
	scanf("%d", &data);

	Nodeptr *current = start;

	while (current != NULL) {
		if (data == current->data) {
			if (current == endNode) {
				addToRight();
				break;
			}
			Nodeptr *newNode = (Nodeptr*)malloc(sizeof(Nodeptr));

			printf("What is the Node?\n");
			scanf("%d", &newNode->data);
			Nodeptr* currentNext = current->next;

			current->next = newNode;
			newNode->previous = current;
			newNode->next = currentNext;
			currentNext->previous = newNode;
			printTheNodes();

			return;

		}
		current = current->next;
	}
}

void addMiddleBefore() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
	}

	int data;
	printf("Before which Node?\n");
	scanf("%d", &data);

	Nodeptr *current = endNode;

	while (current != NULL) {
		if (data == current->data) {
			if (current == start) {
				addToLeft();
				break;
			}
			Nodeptr *newNode = (Nodeptr*)malloc(sizeof(Nodeptr));

			printf("What is the Node?\n");
			scanf("%d", &newNode->data);
			Nodeptr* currentPrevious = current->previous;

			current->previous = newNode;
			newNode->next = current;
			newNode->previous = currentPrevious;
			currentPrevious->next = newNode;
			printTheNodes();

			return;
		}
		current = current->previous;

	}



}

void deleteNodeFromEnd() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
	}
	else if (start == endNode) {
		free(start);
		start = NULL;
		endNode = NULL;
		puts("Delete was succeeded");
		printTheNodes();
	}
	else {
		Nodeptr* tempPtr;
		tempPtr = endNode;
		endNode = endNode->previous;
		endNode->next = NULL;
		free(tempPtr);
		puts("Delete was succeeded");
		printTheNodes();
	}
}

void deleteNodeFromStart() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
	}else if (start == endNode) 
	{
		free(start);
		start = NULL;
		endNode = NULL;
		puts("Delete was succeeded");
		printTheNodes();
	}
	else {
		Nodeptr* tempPtr;
		tempPtr = start;
		start = start->next;
		start->previous = NULL;
		free(tempPtr);
		puts("Delete was succeeded");
		printTheNodes();
	}
}

void deleteAnyNode() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
		return;
	}
	int data;
	printf("Which Node?\n");
	scanf("%d", &data);
	Nodeptr *current = start;
	while (current != NULL) {
		if (data == current->data) {
			if (current == endNode) {
				deleteNodeFromEnd();
				break;
			}
			if (current == start) {
				deleteNodeFromStart();
				break;
			}

			Nodeptr *currentNext = (Nodeptr*)malloc(sizeof(Nodeptr));
			Nodeptr *currentPrevious = (Nodeptr*)malloc(sizeof(Nodeptr));
			currentNext = current->next;
			currentPrevious = current->previous;
			currentNext->previous = currentPrevious;
			currentPrevious->next = currentNext;
			current->next = NULL;
			current->previous = NULL;
			free(current);
			printTheNodes();

			return;

		}
		current = current->next;
	}
	return;
	
}

void deleteAllNode() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
	}
	else if (start == endNode)
	{
		free(start);
		start = NULL;
		endNode = NULL;
		puts("Delete was succeeded");
		printTheNodes();
	}
	else {
		Nodeptr* startNext;
		while (start != NULL) {
			startNext = start->next;
			free(start);
			start = startNext;
		}
		endNode = NULL;
		puts("Delete was succeeded");
		printTheNodes();

	}
}

void printOddNumbers() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
		puts("");
	}
	else if (start == endNode&& start->data%2==1) {
		printf("Linked List of Odd Num : {%d}\n", start->data);
	}
	else
	{
		Nodeptr* current;
		current = start;
		printf("Linked List of Odd Num : {");
		while (current != NULL)
		{
			if (current->data % 2 == 1) {
				printf("%d ", current->data);
			}
			current = current->next;
		}
		printf("}");
		puts("");
	}
	
}

void printEvenNumbers() {
	if (start == NULL && endNode == NULL) {
		puts("The list is empty");
		puts("");
	}
	else if (start == endNode && start->data % 2 == 0) {
		printf("Linked List of Even Num : {%d}\n", start->data);
	}
	else
	{
		Nodeptr* current;
		current = start;
		printf("Linked List of Even Num : {");
		while (current != NULL)
		{
			if (current->data % 2 == 0) {
				printf("%d ", current->data);
			}
			current = current->next;
		}
		printf("}");
		puts("");
	}

}

void menu() {
	int choice;
	puts("");
	printf("\t\twelcome, please select one\n");
	printf("\t\t1- add a node to left\n");
	printf("\t\t2- add a node to right\n");
	printf("\t\t3- add a node to middle after a node\n");
	printf("\t\t4- add a node to middle before a node\n");
	printf("\t\t5- printf the list forward\n");
	printf("\t\t6- printf the list backward\n");
	printf("\t\t7- delete a node (front)\n");
	printf("\t\t8- delete a node (back)\n");
	printf("\t\t9- delete any node\n");
	printf("\t\t10- delete all nodes\n");
	printf("\t\t11- print odd numbers\n");
	printf("\t\t12- print even numbers\n");
	printf("\t\t0- exit\n");
	printf("? :  ");
	scanf("%d", &choice);

	switch (choice) {
	case 1:
		addToLeft();
		break;
	case 2:
		addToRight();
		break;
	case 3:
		addMiddleAfter();
		break;
	case 4:
		addMiddleBefore();
		break;
	case 5:
		printTheNodes();
		break;
	case 6:
		printTheNodesBackwards();
		break;
	case 7:
		deleteNodeFromStart();
		break;
	case 8:
		deleteNodeFromEnd();
		break;
	case 9:
		deleteAnyNode();
		break;
	case 10:
		deleteAllNode();
		break;
	case 11:
		printOddNumbers();
		break;
	case 12:
		printEvenNumbers();
		break;
	default:
		exit(0);
		break;
	}

}
