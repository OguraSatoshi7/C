#pragma once
#include <stdio.h>

//prototypes
void addToLeft(void);
void printTheNodes(void);
void printTheNodesBackwards(void);
void addToRight(void);
void addMiddleAfter(void);
void addMiddleBefore(void);
void deleteNodeFromEnd(void);
void deleteNodeFromStart(void);
void deleteAnyNode();
void deleteAllNode(void);
void printOddNumbers(void);
void printEvenNumbers(void);
void menu(void);
#pragma once
